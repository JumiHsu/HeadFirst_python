# setup.py
from distutils.core import setup

setup(
    name = 'nestPrint',
    version = '1.1.0',
    py_modules = ['nestPrint'],
    author='Jumi',
    author_email='japanjumi@gmail.com',
    url='',
    description='print 出一個，混和 str、int、list 形式的，多層級 list'
    )
